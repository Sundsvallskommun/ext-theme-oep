Ext.define('OsynligOepTheme.ProgressBar', {
    override: 'Ext.ProgressBar'
});